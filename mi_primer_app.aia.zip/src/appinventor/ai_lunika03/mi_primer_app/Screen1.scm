#|
$JSON
{"authURL":["ai2a.appinventor.mit.edu"],"YaVersion":"237","Source":"Form","Properties":{"$Name":"Screen1","$Type":"Form","$Version":"32","ActionBar":"True","AppName":"mi_primer_app","Title":"Screen1","Uuid":"0","$Components":[{"$Name":"Bot\u00f3n1","$Type":"Button","$Version":"8","Height":"-2","Width":"-2","Image":"a0f6d8722e2ca13e433591c68bc5401f.jpg","Uuid":"-744011617"},{"$Name":"Image1","$Type":"Image","$Version":"8","Uuid":"1363017003","Visible":"False"},{"$Name":"Sonido1","$Type":"Sound","$Version":"4","Source":"sonido.mp3","Uuid":"-495722558"}]}}
|#